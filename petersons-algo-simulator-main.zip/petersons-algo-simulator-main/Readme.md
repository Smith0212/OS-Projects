
# Peterson's Algorithm Simulator

## Installation

Install my-project with npm

```bash
  git clone https://github.com/Aum3010/petersons-algo.git
  cd petersons-algo
  # To install dependencies
  npm i 
  # To install dependencies
  npm run dev
  # go to localhost:5173
```
    