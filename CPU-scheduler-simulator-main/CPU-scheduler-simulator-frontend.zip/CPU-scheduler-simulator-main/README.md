# OS-Project

## Tech Stack
<img src="https://github.com/devicons/devicon/blob/master/icons/react/react-original-wordmark.svg"
		title="React" alt="React" width="48" height="48"/>&nbsp; &nbsp; &nbsp;
<img src="https://github.com/devicons/devicon/blob/master/icons/materialui/materialui-original.svg"
		title="MUI" alt="MUI" width="48" height="48"/>&nbsp; &nbsp; &nbsp;
<img src="https://github.com/devicons/devicon/blob/master/icons/javascript/javascript-original.svg"
		title="JavaScript" alt="JavaScript" width="48" height="48"/>&nbsp; &nbsp; &nbsp;

