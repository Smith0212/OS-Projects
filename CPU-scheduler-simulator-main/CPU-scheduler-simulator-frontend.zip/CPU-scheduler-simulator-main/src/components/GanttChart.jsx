import {
	Table,
	TableContainer,
	TableRow,
	TableCell,
	Paper,
	TableBody,
	Box,
	Typography
} from '@mui/material';
// import gantChart from '../layout/AppLayout'

const GanttChart = props => {
	// set the props to pass in app file
	const { processes ,gantChart} = props;

	// Boiler plate code has been configured as per chart JS
	let ganttProcesses = processes.sort((p1, p2) =>
		p1.completionTime > p2.completionTime
			? 1
			: p1.completionTime < p2.completionTime
			? -1
			: 0
	);
	const colors = [
		{ key: 'color1', color: '#ff0000' },
		{ key: 'color2', color: '#014f22' },
		{ key: 'color3', color: '#0000ff' },
		{ key: 'color4', color: '#401f14' },
		{ key: 'color5', color: '#ff00ff' },
		{ key: 'color6', color: '#6f33f3' },
		{ key: 'color7', color: '#00ffff' }
	  ];
	const keys = [];
	const values = [];
	const objs = []
	// Obtain key and value pair from data ie PID and remaining time for burst
	// console.log('gantchart', gantChart)
	for (const key in gantChart) {
		const obj = gantChart[key];
		objs.push(obj)
		for (const objKey in obj) {
		  const objkey = objKey;
		  const objValue = obj[objKey];
		  keys.push(objkey)
		  values.push(objValue)
		//   console.log(objs,keys,values);
		  break; 
		}}

	// console.log('keys', keys)
	// UI part
	return (
		<TableContainer
			sx={{
				overflow: 'scroll',
				overscrollBehavior: 'contain',
				// Remove external scrollbar
				'&::-webkit-scrollbar': { display: 'none' }
			}}
		>
			<Table
				component={Paper}>
				<TableBody>
					{/* PID Row */}
					<TableRow
						sx={{
							'&:last-child td, &:last-child th': {
								border:'none',
								// textAlign:'center'
							},
							outlineOffset: '-2px'
						}}
					>
						<TableCell sx={{ width: '300px' , fontSize:'1.2em'}}>PID</TableCell>

						{keys.map((key) => (
							<TableCell key={key} align='center' sx={{fontSize:'1.2em'}}>
								{key}
							</TableCell>
						))}
					</TableRow>

					{/* Time Row */}
					<TableRow
						sx={{
							'&:last-child td, &:last-child th': {
								border:'black'
								// textAlign:'center'
							},
							outlineOffset: '-2px',
						}}
					>
						<TableCell sx={{ width: '300px' , fontSize:'1.2em'}}>TIME</TableCell>
						{values.map((key) => (
							<TableCell key={key} align='center' sx={colors[key]}>
								{key}
							</TableCell>
						))}
					</TableRow>
				</TableBody>
			</Table>
		</TableContainer>
	);
};

export default GanttChart;