const mongoose = require("mongoose");

const CPUSchedulingSchema = new mongoose.Schema({
    processes:{
        type: Array,
        required: true
    },
    avgTAT: Number,
    avgWT: Number,
    date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("CPUScheduling", CPUSchedulingSchema);