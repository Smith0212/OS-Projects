const express = require("express");
const router = express.Router();
const { priorityScheduling } = require("../controllers/premptivePriorityScheduling");

router.post("/schedule", priorityScheduling);
router.get("/schedule", priorityScheduling);

module.exports = router;