const CPUScheduling = require("../models/CPUScheduling");
function priorityScheduling(req, res) {
  let { processes } = req.body;
  let currentTime = 0, completed = 0, avgTAT = 0, avgWT = 0;
  let n = processes.length;
  if (n == 0) return [];
  let isCompleted = Array(n).fill(0);
  let burstRemaining = processes.map((x) => x.burstTime);
  let ganttChart = [];

  while (completed !== n) {
    let index = -1;
    let max = Number.MAX_SAFE_INTEGER;
    for (let i = 0; i < n; i++) {
      if (processes[i].arrivalTime <= currentTime && isCompleted[i] === 0) {
        if (processes[i].priority < max) {
          max = processes[i].priority;
          index = i;
        }
        if (processes[i].priority === max) {
          if (processes[i].arrivalTime < processes[index].arrivalTime) {
            max = processes[i].priority;
            index = i;
          }
        }
      }
    }
    if (index !== -1) {
      if (burstRemaining[index] === processes[index].burstTime) {
        processes[index].startTime = currentTime;
      }
      ganttChart.push(processes[index].pid);
      burstRemaining[index] -= 1;
      currentTime++;
      prev = currentTime;
      if (burstRemaining[index] === 0) {
        processes[index].completionTime = currentTime;
        processes[index].turnAroundTime =
          processes[index].completionTime - processes[index].arrivalTime;
        processes[index].waitingTime = processes[index].turnAroundTime - processes[index].burstTime;
        processes[index].responseTime = processes[index].startTime - processes[index].arrivalTime;
        avgTAT += processes[index].turnAroundTime;
        avgWT += processes[index].waitingTime;

        isCompleted[index] = 1;
        completed++;
      }
    } else {
      currentTime++;
      ganttChart.push("-1");
    }
  }
  const counts = [];
  let currentCount = 1;
  
  for (let i = 0; i < ganttChart.length; i++) {
    if (ganttChart[i] !== ganttChart[i+1]) {
      if(ganttChart[i] == "-1")
        counts.push({ [`IDLE`]: currentCount });
      else
        counts.push({ [`PID ${ganttChart[i]}`]: currentCount });
      currentCount = 1;
    } else {
      currentCount++;
    }
  }
  avgTAT /= processes.length;
  avgWT /= processes.length;
  let data = {
    processes,
    avgTAT,
    avgWT,
    ganttChart: counts,
    date: new Date()
  }
  let newCPUScheduling = new CPUScheduling(data);
  newCPUScheduling.save();
  res.json(data);
}

module.exports = { priorityScheduling };

/*

{
  "processes":[
    "{ pId: 1, arrivalTime: 0, burstTime: 6, priority: 0 }",
    "{ pId: 2, arrivalTime: 2, burstTime: 2, priority: 15 }",
    "{ pId: 3, arrivalTime: 6, burstTime: 4, priority: 7 }",
    "{ pId: 4, arrivalTime: 7, burstTime: 2, priority: 6 }",
    "{ pId: 5, arrivalTime: 4, burstTime: 3, priority: 10}"
    ],
    "date": "2023-02-08T11:44:55.624Z"
}

*/