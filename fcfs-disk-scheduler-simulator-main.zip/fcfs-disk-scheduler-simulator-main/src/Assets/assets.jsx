
const assets = {
	theme: {
		palette: {
			mode: 'light',
			background: {
				paper: '#fff'
			},
			primary: {
				main: '#00ffff'
			}
		}
	}
};

export default assets;